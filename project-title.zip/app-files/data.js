var APP_DATA = {
  "scenes": [
    {
      "id": "0-front-yard",
      "name": "Front yard",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.6462428256710524,
        "pitch": -0.06152203852719751,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [
        {
          "yaw": 1.3768069190729193,
          "pitch": 0.06258548425672927,
          "rotation": 0,
          "target": "1-backyard"
        },
        {
          "yaw": 0.5380038467216259,
          "pitch": 0.017739438535969043,
          "rotation": 0,
          "target": "2-lobby"
        },
        {
          "yaw": -0.5434008440998337,
          "pitch": 0.03455247708309983,
          "rotation": 0,
          "target": "24-side-backyard"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-backyard",
      "name": "Backyard",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.965023699312951e-9,
          "pitch": 0.07643804095024365,
          "rotation": 0,
          "target": "12-service-lobby"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.15389657711263993,
          "pitch": 0.06929107990347205,
          "title": "Service Entrance",
          "text": "Text"
        }
      ]
    },
    {
      "id": "2-lobby",
      "name": "Lobby",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.1138589247007147,
          "pitch": 0.17577427625030495,
          "rotation": 0,
          "target": "3-majlis"
        },
        {
          "yaw": 0.9426734803931982,
          "pitch": 0.21203083309263704,
          "rotation": 0,
          "target": "9-courtyard"
        },
        {
          "yaw": -0.10809061263061182,
          "pitch": 0.14568446495489518,
          "rotation": 0,
          "target": "10-gust-bedroom"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.16861313346838358,
          "pitch": 0.540750332548976,
          "title": "Lobby",
          "text": "Text"
        }
      ]
    },
    {
      "id": "3-majlis",
      "name": "Majlis",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.2443945882558385,
          "pitch": 0.16464864162124648,
          "rotation": 0,
          "target": "4-washing"
        },
        {
          "yaw": 2.2846160718641997,
          "pitch": 0.10363008124255302,
          "rotation": 0,
          "target": "2-lobby"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.4846216925767788,
          "pitch": 0.019321385823472426,
          "title": "Majlis",
          "text": "Text"
        }
      ]
    },
    {
      "id": "4-washing",
      "name": "washing",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.8211080255126575,
          "pitch": 0.23504929680900766,
          "rotation": 0,
          "target": "12-service-lobby"
        },
        {
          "yaw": -1.2555806928344673,
          "pitch": 0.3193368131664869,
          "rotation": 0,
          "target": "3-majlis"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.8469767406360926,
          "pitch": -0.07693341344589655,
          "title": "Washing Area",
          "text": "Text"
        }
      ]
    },
    {
      "id": "5-kitchen",
      "name": "kitchen",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.0156832395563775,
          "pitch": 0.051853194110911716,
          "rotation": 0,
          "target": "11-liwan-lobby"
        },
        {
          "yaw": 1.922437750840337,
          "pitch": 0.16642003589825904,
          "rotation": 0,
          "target": "12-service-lobby"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.5505989331589234,
          "pitch": 0.10922463187407772,
          "title": "Kitchen",
          "text": "Text"
        }
      ]
    },
    {
      "id": "6-liwan",
      "name": "Liwan",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 3.0600069968930095,
          "pitch": 0.6293137596645391,
          "rotation": 0,
          "target": "11-liwan-lobby"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.6054926562031469,
          "pitch": -0.009687660714458701,
          "title": "Liwan",
          "text": "Text"
        }
      ]
    },
    {
      "id": "7-living-room",
      "name": "Living Room",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.074291416517452,
          "pitch": 0.19988047754339178,
          "rotation": 0,
          "target": "8-staircse"
        },
        {
          "yaw": 0.9736550277905227,
          "pitch": 0.16351087409588239,
          "rotation": 0,
          "target": "11-liwan-lobby"
        },
        {
          "yaw": 1.708268178314297,
          "pitch": 0.15757652229833496,
          "rotation": 0,
          "target": "9-courtyard"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.579460273630616,
          "pitch": 0.07463539650160911,
          "title": "Living Room",
          "text": "Text"
        }
      ]
    },
    {
      "id": "8-staircse",
      "name": "Staircse",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.07782668169663864,
        "pitch": 0.030531132094267832,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [
        {
          "yaw": 1.291575514755964,
          "pitch": 0.2489416629388863,
          "rotation": 0,
          "target": "7-living-room"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "9-courtyard",
      "name": "courtyard",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.4036664980409199,
          "pitch": 0.010835230125589845,
          "rotation": 0,
          "target": "5-kitchen"
        },
        {
          "yaw": -0.14623216559176022,
          "pitch": 0.011656376314363115,
          "rotation": 0,
          "target": "11-liwan-lobby"
        },
        {
          "yaw": -0.6074820059011863,
          "pitch": 0.026598851917071897,
          "rotation": 0,
          "target": "7-living-room"
        },
        {
          "yaw": -2.927403775128308,
          "pitch": 0.06661120782016461,
          "rotation": 0,
          "target": "2-lobby"
        },
        {
          "yaw": -1.6879281771746157,
          "pitch": 0.03151118529102881,
          "rotation": 0,
          "target": "10-gust-bedroom"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.6770757843026622,
          "pitch": 0.21754393595486654,
          "title": "Courtyard",
          "text": "Text"
        }
      ]
    },
    {
      "id": "10-gust-bedroom",
      "name": "gust bedroom",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 3.005131211951575,
          "pitch": -0.03316564953807699,
          "rotation": 0,
          "target": "8-staircse"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.40961529791161233,
          "pitch": -0.038013412512883704,
          "title": "Gust Bedroom",
          "text": "Text"
        }
      ]
    },
    {
      "id": "11-liwan-lobby",
      "name": "liwan lobby",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.6634781902410261,
          "pitch": 0.24084872859851103,
          "rotation": 0,
          "target": "6-liwan"
        },
        {
          "yaw": -1.0938086719556601,
          "pitch": 0.24049483861877796,
          "rotation": 0,
          "target": "9-courtyard"
        },
        {
          "yaw": -0.30996276296248304,
          "pitch": 0.05294018077574947,
          "rotation": 0,
          "target": "7-living-room"
        },
        {
          "yaw": 2.5050922771318653,
          "pitch": 0.008060794011289119,
          "rotation": 0,
          "target": "5-kitchen"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "12-service-lobby",
      "name": "service lobby",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.3776929927982486,
          "pitch": 0.21688389836441146,
          "rotation": 0,
          "target": "5-kitchen"
        },
        {
          "yaw": -1.531106423472762,
          "pitch": 0.16592242139376268,
          "rotation": 0,
          "target": "3-majlis"
        },
        {
          "yaw": -1.6427385580015859,
          "pitch": 0.3643760710335009,
          "rotation": 0,
          "target": "4-washing"
        },
        {
          "yaw": 2.776089914275601,
          "pitch": 0.5599983917130054,
          "rotation": 0,
          "target": "1-backyard"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "13-bedroom-1",
      "name": "bedroom 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.6846239232358471,
          "pitch": 0.05425367614114052,
          "rotation": 0,
          "target": "14-dressing-bedroom-1"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.45723003528060246,
          "pitch": -0.034347609996835615,
          "title": "Bedroom",
          "text": "Text"
        }
      ]
    },
    {
      "id": "14-dressing-bedroom-1",
      "name": "dressing bedroom 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": -0.017672170311204383,
          "pitch": 0.4209155385586474,
          "title": "Dressing Room",
          "text": "Text"
        }
      ]
    },
    {
      "id": "15-kids-bedroom",
      "name": "kids bedroom",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": -0.42342513124192394,
          "pitch": 0.3690020639254161,
          "title": "Kids Bedroom",
          "text": "Text"
        }
      ]
    },
    {
      "id": "16-master-bedroom",
      "name": "Master bedroom",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.665364842174583,
          "pitch": 0.4341188369377793,
          "rotation": 0,
          "target": "17-master-dressing"
        },
        {
          "yaw": -1.9011884819896885,
          "pitch": 0.38190630235588685,
          "rotation": 0,
          "target": "18-bathroom"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.783211837471562,
          "pitch": 0.03338678336416834,
          "title": "Master Bedroom",
          "text": "Text"
        }
      ]
    },
    {
      "id": "17-master-dressing",
      "name": "master dressing",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.551821913370608,
          "pitch": 0.5668158611102534,
          "rotation": 0,
          "target": "17-master-dressing"
        },
        {
          "yaw": 2.2850089884777116,
          "pitch": 0.2808682770196853,
          "rotation": 0,
          "target": "18-bathroom"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.10856124081066199,
          "pitch": 0.22733838322465516,
          "title": "Dressing Room",
          "text": "Text"
        }
      ]
    },
    {
      "id": "18-bathroom",
      "name": "Bathroom",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -3.1011862744826555,
          "pitch": 0.0882809773185258,
          "rotation": 0,
          "target": "17-master-dressing"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0,
          "pitch": 0,
          "title": "Bathroom",
          "text": "Text"
        }
      ]
    },
    {
      "id": "19-up-living-room",
      "name": "up living room",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.3529029115431435,
          "pitch": -0.05595974145445126,
          "rotation": 0,
          "target": "13-bedroom-1"
        },
        {
          "yaw": 1.5705992331609293,
          "pitch": 0.009056701547265789,
          "rotation": 0,
          "target": "15-kids-bedroom"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.3066008240028033,
          "pitch": 0.24833463845918047,
          "title": "Living Room",
          "text": "Text"
        }
      ]
    },
    {
      "id": "20-up-lobby",
      "name": "up lobby",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.8496727088644267,
          "pitch": 0.06741424979278676,
          "rotation": 0,
          "target": "16-master-bedroom"
        },
        {
          "yaw": 0.005849774819232323,
          "pitch": 0.24749633772361435,
          "rotation": 0,
          "target": "21-balcony"
        },
        {
          "yaw": 1.7479068083126617,
          "pitch": 0.046850216369952236,
          "rotation": 0,
          "target": "22-staircase-up"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "21-balcony",
      "name": "Balcony",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.47236023400796,
          "pitch": 0.44481734780519666,
          "rotation": 0,
          "target": "20-up-lobby"
        },
        {
          "yaw": -2.3677345494505513,
          "pitch": -0.001136728606882187,
          "rotation": 0,
          "target": "16-master-bedroom"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.17631387341575433,
          "pitch": 0.07123930821995828,
          "title": "Balcony",
          "text": "Text"
        }
      ]
    },
    {
      "id": "22-staircase-up",
      "name": "staircase up",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.5301265279200251,
          "pitch": 0.07437767741884649,
          "rotation": 0,
          "target": "13-bedroom-1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "23-facad",
      "name": "facad",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.009961466997385315,
        "pitch": 0.08049116643034893,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [
        {
          "yaw": -0.48037846903915593,
          "pitch": 0.1247234936636552,
          "rotation": 0,
          "target": "0-front-yard"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "24-side-backyard",
      "name": "Side Backyard",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.0939119600216074,
          "pitch": 0.037289660318659656,
          "rotation": 0,
          "target": "6-liwan"
        },
        {
          "yaw": 1.4559325733158186,
          "pitch": 0.07076898352648087,
          "rotation": 0,
          "target": "0-front-yard"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": true
  }
};
